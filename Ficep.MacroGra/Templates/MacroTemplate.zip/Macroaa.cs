﻿using devDept.Eyeshot.Entities;
using Ficep.RobServer.Data;
using Ficep.Utils;
using Ficep.RobServer.Utility3D;
using System.Collections.Generic;
using System.Linq;

namespace Ficep.MacroGra
{
    public class $safeitemname$ : EyeMacro
    {

        public $safeitemname$(IWorkPiece wp, ICopeParams param, string macroClassName, string macroName, EyeParam eyeParam, uint lineNumber = 0)
                     : base(wp, param, macroClassName, macroName, eyeParam, lineNumber)
        {
            ProfilesEnabled = "I";
        }

        public override bool CreateMacro()
        {
            ///////////////////////////////
            //      TESTA: fissa
            ///////////////////////////////
            //  Verifico che il profilo sia tra quelli abilitati
            if (!ProfilesEnabled.Contains(CodePrf))
                return false;

            //  Validazione parametri geometrici
            if (Validate() != ErrMacro.No_err)
                return false;

            ///////////////////////////////
            //      CORPO: variabile
            ///////////////////////////////
            //
            //  Lista dei punti che descrivono il contorno da estrudere
            //
            List<ProgramPoint> macroPoint = new List<ProgramPoint>();
            List<Brep> breps = new List<Brep>();

            double extrusionDepth = 0;
            string extrusionPlane = "";

            ////
            ////  ESTRUSIONE ANIMA
            ////
            //extrusionPlane = "C";
            //
            //if (CodePrf == "L")
            //    extrusionDepth = SA;
            //else if (CodePrf == "F")
            //    extrusionDepth = TA;
            //else
            //    extrusionDepth = SB;
            //
            //macroPoint.Add(new ProgramPoint(0, 0, 0, 0));
            //macroPoint.Add(new ProgramPoint(ParA, 0, 0, 0));
            //macroPoint.Add(new ProgramPoint(ParA, ParB, 0, ParR));
            //macroPoint.Add(new ProgramPoint(ParE, ParD - (ParD - ParB) * ParE / ParA, 0, 0));
            //macroPoint.Add(new ProgramPoint(0, ParD + ParC, 0, 0));
            //
            //EyeGeometryUtils.AddContourExtrusion(macroPoint, extrusionPlane, extrusionDepth, MirrorInizialeFinale, MirrorSideASideB, MirrorAltoBasso, Wp, TolBrep, TolLinear, TolAngle, TolWebFlange, ref breps, Surplus);

            ////
            ////  CIANFRINI
            ////
            //if (ParALFA > 0 || ParBETA > 0)
            //{
            //    //
            //    //  Inserire tante chiamate quanti sono i cianfrini
            //    //  Es: prima chiamata per cianfrino esterno, seconda chiamata per cianfrini interno inferiore,
            //    //      terza chiamata per cianfrino interno superiore
            //    //
            //    //  EyeGeometryUtils.AddLineChamferExt(parA, parALFA, parF, parG, parJ, sVX, sSide, Wp, Surplus, TolThickness, BrepTol, ref breps);
            //    //
            //    EyeGeometryUtils.AddLineChamfer(ParA, ParALFA, ParBETA, ParF, ParG, ParJ, VX, Side, Wp, Surplus, TolWebFlange, TolBrep, ref breps);
            //}

            ///////////////////////////////
            //      CODA: fissa
            ///////////////////////////////

            Features.AddRange(breps.Select(brep => new EyeFeature(brep)));

            return true;
        }

    }
}